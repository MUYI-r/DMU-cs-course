#ifndef CONST_H
#define CONST_H
#define MaxSize 10
//栈中最多只有 10 个元素
#define TRUE 1
#define FALSE 0
#define ERROR 0
#define OVERFLOW -2
#define OK 1
#define MAXSIZE 20
#define MAXLEN 100
//字符串的最大长度#endif
#endif